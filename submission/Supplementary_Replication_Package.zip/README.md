# Replication package

Manuscript: "Who gains from a market upgrade? Stock liquidity and prices around Vietnam's FTSE Russell reclassification" (submitted to Finance Research Open; anonymized for review).

## Contents
- `data/raw/*.csv`: daily open, high, low, close and volume for the 405 common stocks listed on HOSE on 24 September 2026, 1 October 2024 to 23 September 2026, downloaded with the open-source `vnstock` library (VCI source); `data/hose_listing_VCI_20260924.csv` lists the universe; `fetch_prices.py` is the download script.
- `code/`: R scripts that produce every table and figure.
- `output/`: the result files the scripts write; `output/TABLE_SOURCE_MAP.md` maps each manuscript table and figure to its file.

## How to reproduce
Run from the package root (R >= 4.3; packages data.table, fixest, MatchIt, ggplot2):

    Rscript code/analysis.R
    Rscript code/analysis_extensions.R
    Rscript code/analysis_revision2.R      # also evaluates code/analysis_revision.R
    Rscript code/figure1.R
    Rscript code/figure2.R

A clean re-run (R 4.3.3, fixest 0.14.2, MatchIt 4.5.5, data.table 1.14.10) reproduces all 48 output tables to a relative tolerance of 1e-6. Joint pre-trend Wald p-values use the number of stock clusters minus one as denominator degrees of freedom (fixest >= 0.14 default); older fixest versions report p-values with residual degrees of freedom (F statistics identical).

## Data terms
Prices and volumes are public market data retrieved through vnstock from VCI. Users should check the data provider's terms before redistributing the raw files.
